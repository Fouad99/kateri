# INF600G - Séquence 1 - Personas

- Auteur: Fouad M. Serradj (`SERM21019100`)

## Personas

**Consignes**: _Définissez ici vos personas, en ajoutant de nouveaux personas et en enrichissant ceux déjà décrits ci-dessous_

## Fred

- Age : 84 ans
- Profession : Architecte (à la retraite)
- Connaissances numérique : très faible
- Handicaps mentaux :
  - Type : Depressions momentanées | Statut d'avancement : moyen
- Handicaps physiques :
  - Type : Troubles moteurs | Statut d'avancement : faible
- Intêret pour le projet :
  1. Rompre l'ennui du quotidien
  2. Suivre l'évolution de sa perte de motricité

_Fred réside dans cet établissement depuis 8 ans, et n'a plus de famille qui vient en visite. Les journées sont longues, et malgré les efforts de l'équipe d'encadrement de la résidence, l'ennui est présent au quotidien. Lors d'une visite du médecin l'an dernier, des troubles de la motricité ont été diagnostiqués, principalement dans les mains, qui se manifestent par de légers tremblements. Depuis, Fred a peur de perdre son autonomie et de devoir dépendre du personnel de la résidence, qui, même s'ils sont charmants, lui donnerait l'impression de dépendre de quelqu'un. Le numérique, c'est pas vraiment son truc, et ça a l'air tellement compliqué à utiliser ... A son époque, on dessinait les plans des batiments à la table à dessin, pas comme tout ces jeunes de maintenant qui utilisent des ordinateurs._

## Camille

- Age : 75 ans
- Profession : Comptable (à la retraite)
- Connaissances numérique : avancée
- Handicaps mentaux : Aucun
- Handicaps physiques :
  - Type : Baisse de la vue | Statut d'avancement : faible
- Intêret pour le projet :
  1. Tester ses connaissances et remporter le championnat de la résidence
  2. Apprendre de nouvelles choses.

_Camille vient d'arriver dans la résidence. Sa famille a déménagé en Colombie-Britanique quand son fils a changé d'emploi il y a 5 ans, et ses petits-enfants lui manque. Totalement autonome, Camille est très à l'aise avec le numérique, et utilise Skype régulièrement pour appeller ses petits-enfants, et clavarder avec ses anciens collègues du cabinet. Vivre en résidence est une sécurité à cause de la baisse de sa vue, qui fait parti des désavantages de la vieillesse. C'est la vie. Mettre son condo en location pour déménager ici lui a fait un peu de peine, mais la présence médicale 24/7 rend son environement de vie sécuritaire, en cas de chute par exemple._

## Dominique

- Age : 83 ans
- Profession : Pilote en aviation civile (à la retraite)
- Connaissances numérique : moyenne
- Handicaps mentaux :
  - Type : Alzheimer | Statut d'avancement : fort
- Handicaps physiques :
  - Type : Baisse de la vue | Statut d'avancement : moyen
- Intêret pour le projet :
  1. Entrainer et maintenir sa mémoire
  2. Entreprendre des activités de reflexion

_Dominique vit dans la résidence depuis 6 ans. Dominique est de nature indépendant et ne supporte pas l'idée d'être un poids sur sa famille proche. Il a décidé de venir vivre en résidence depuis son diagnostic d'Alzheimer. Dominique apprécie particulièrement les visites de ses petits-enfants à chaque fin de semaine. Depuis 3 ans sa vue à baissé considérablement et l'état de son Alzheimer reste stationnaire grâce aux suivis du personnel de santé. Dominique a toujours eu une personnalité de leader et finit toujours par avoir le dernier mot. Il est assez à l'aise avec l'outil numérique. Son utilisation réside principalement en Facebook(messenger) afin de communiquer avec sa famille et ses anciens amis. Ainsi qu'une application de sport en ligne pour suivre le Hockey. Dominique aime lire et gueter les erreurs d'orthographe qui paraissent dans les journaux quotidiens, car sa l'aide a garder une memoire fonctionelle, comme il le dit sans cesse_

## Marie-France

- Age : 68 ans
- Profession : Chef cuisiniere dans un grand restaurant (à la retraite)
- Connaissances numérique : avancée
- Handicaps mentaux : Aucun
- Handicaps physiques :
  - Type : Arthrose de la hanche | Statut : faible
- Intêret pour le projet :
  1. Socialiser avec les autres residents a travers des activites diverses
  2. Apprendre de nouvelles choses

_Marie-France vit dans la résidence depuis 8 mois. Du au fait que son unique fils traverse un moment très difficile dans sa vie, le décès récent de son mari, Marie-France a décidé d'aller vivre dans une résidence et de laisser son fils Jerome et sa famille vivre dans son petit condos. Marie-France adore recevoir la visite de Sandra, sa petite fille de 14 ans qui partage la même passion que sa grand-mère qui est la cuisine. Marie-France a une nature joviale et un esprit ouvert sur le monde. Elle aime partager ses idées et transmettre son savoir en matière de cuisine. Elle a une chaine Youtube depuis 2 ans où elle fait des tutoriels et du contenu dymanique de nature culinaires. Marie-France est à l'aise avec l'outil numérique. Elle l'utilise a des fins de communication (messenger, skype et whatsapp) avec sa famille et ses amis, ainsi que Youtube et quelques blogs de cuisine afin de continuer a apprendre plus_

## Jerome

- Age : 38 ans
- Profession : Développeur informatique
- Connaissances numérique : avancée
- Handicaps mentaux : Aucun
- Handicaps physiques : Aucun
- Intêret pour le projet :
  1. Creer du contenu de quizs pour sa mere (Marie-France) qui est en résidence
  2. Suivre les resultats des quizs de sa mere

_Jerome est le fils est l'unique fils de Marie-France. Marié depuis bientot 15 ans, Jerome a deux filles et un fils. Jerome est de nature calme est introverti. Il vit mal le depart de Marie-France en residence, il essaye d'etre present le plus possible dans la vie quotidienne de sa mere. Jerome parle tous les jours avec Marie-France, principalement a travers Messenger (facebook). Ce projet de quiz l'interesse particulierement, car d'un coté, il y voit un moyen efficace a rester a jour des performances mentales de Marie-France. D'un autre coté, il y voit une maniere de travailler sur le mémoire de sa mere en créant des quizs qui se basent sur sa vie et ses souvenirs_

## Jean

- Age : 72 ans
- Profession : Ouvrier dans la construction (à la retraite)
- Connaissances numérique : faible
- Handicaps mentaux :
  - Type : Perte de memoire momentanées | Statut d'avancement : moyen
- Handicaps physiques :
  - Type : Baisse de la vue | Statut d'avancement : moyen
  - Type : Maladie de Parkinson (gestes rigides et incontrôlables) | Statut d'avancement : fort
- Intêret pour le projet :
  1. Suivre l'evolution de sa maladie de parkinson
  2. atténuer les effets de Parkinson a l'aide de contenu "ASMR"
  3. Entreprendre des activités de concentration

_Jean vit dans la résidence depuis 3 ans. Jean a été diagnostiqué atteint de Parkinson depuis bientôt 4 ans à un stade avance. De ce fait les deux fils de Jean ont jugé nécessaire de le placer en résidence afin de recevoir l'assistance dont il a besoin. Jean est proche de ses petits-enfants et profite de chaque instant passé auprès d'eux à chaque visite. Jean est de nature calme et introvertie. Jean n'est pas très à l'aise avec l'outil numérique et préfère les bons vieux appels GSM pour communiquer avec son entourage. Cependant, grand fan de radio, il a développé ces six derniers mois une passion pour l'internet et particulièrement une application qui lui donne accès à toutes les radios émises dans le monde. Jean a aussi éprouvé un intérêt certain à un genre de contenu vidéo nommé "ASMR" qui sont des vidéos de relaxation sur les plateformes Youtube et Twitch. Jean a remarqué que ce genre de contenu attenue ses gestes incontrôlées et l'aide a focalisé sa concentration sur des sujets particulier_

## Celia

- Age : 26 ans
- Profession : Infirmière dans la résidence
- Connaissances numérique : Excellent
- Handicaps mentaux : Aucun
- Handicaps physiques : Aucun
- Intêret pour le projet :
  1. Suivre l'évolution de santé mentale et physique de ses résidents
  2. Savoir quelles dispositions prendre pour chaque résidents

_Celia travaille dans la residence depuis bientot 1 annee. Celia est nouvellement diplômée en infermerie et est membre de l'Ordre des infirmières et infirmiers du Québec. Celia est une personne passionèe par son travaille. Elle a choisi de travailler dans une residence, car elle veut se spécialiser dans les maladies de personnes ainées. Celia est responsable d'un groupe de 10 residents. Supervise la mise en application des standards et normes d'hygiène personnelle et de l'environnement et avise les personnes concernées afin de s'assurer que les standards et normes soient respectés. Supervise, selon les normes des soins de santé, l'enseignement, par le personnel, aux résidents des soins et des traitements amorcés afin de s'assurer que les soins et traitements soient bien effectués. Celia pense que les technologies numeriques offrent un avantage certain quant a l'etablissement de diagnostic plus profonds et aux suivis plus efficaces des residents._

## Cedric

- Age : 33 ans
- Profession : Préposé aux bénéficiaires
- Connaissances numérique : Excellent
- Handicaps mentaux : Aucun
- Handicaps physiques : Aucun
- Intêret pour le projet :
  1. Apporter les soins appropriés aux residents

_Cedric travaille dans la residence depuis bientot 10 ans. Cedric est une personne simple et serviable. Il aime son travaille et ne changera pas de carriere pour rien au monde. Cedric aide les patients au lever, au moment des repas et au coucher. Il les aide à se laver, à se vêtir ou à se dévêtir et il a la charge de la literie. Il veille à donner aux bénéficiaires les soins appropriés et à respecter leur intégrité et leur dignité, afin de contribuer à leur bien-être. Cedric croit que l'emploie et l'insertion de la technologie dans la vie quotidienne des residents facilitera son travail et lui permettra d'anticiper lequel de ses residents requiert le plus son intention_

## Gregory

- Age : 36 ans
- Profession : Animateur
- Connaissances numérique : Excellent
- Handicaps mentaux : Aucun
- Handicaps physiques : Aucun
- Intêret pour le projet :
  1. Enrichir les activités avec les quizs
  2. Incorporer des tournois de quizs dans le plan d'activités mensuel
  3. Utiliser les resultats de quizs afin de choisir les thematiques de tournois

_Gregory travaille dans le milieux de residence depuis bientot 13 ans. Gregory est une personne extraverti et tres amicale, ce qui lui permet d'etre animateur de façon naturelle. Gregory collabore en grande partie avec la direction pour planifier le calendrier des activités. Sa principale responsabilite est d'animer l'ambiance de la residence en s'asssurant les residents passent un bon moment. Ses taches sont assez diverses. Entre autre, Gregory organise les sorties extérieures ainsi que les événements spéciaux et assure la décoration et la surveillance des residents. Il s'assure aussi que les activités correspondent aux besoins et aux goûts des résidents. Enfin il lui arrive aussi d'organiser des spectacles en engageant des musiciens et autres artistes. Gregory est persuadé que la technologie apportera son lot d'avantage dans la vie des aines dans les residences. Dans ce contexte, il croit qu'un application semblable lui permettra d'enrichir sa palette d'activites et lui permettra de divertir et amuser les residents d'avantage_
