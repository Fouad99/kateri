# INF600G - Séquence 1 - Backlog

- Auteur: Fouad M. Serradj (`SERM21019100`)

**Consignes**: _Complétez les fonctionalités, le jeu de récits utilisateurs, et décrivez le produit minimal viable dont vous livrerez la maquette à la fin de cette séquence_

## Fonctionnalités

Échelle de priorité, de la plus haute à la plus basse :

1. `Cr` : Critique
2. `Ma` : Majeure
3. `El` : Élevée
4. `No` : Normale
5. `Ba` : Basse
6. `Mi` : Mineure
7. `In` : Inexistante

| Identifiant | Description                                                                   | Priorité |
| :---------: | :---------------------------------------------------------------------------- | :------: |
|    `F1`     | Jouer à un quiz                                                               |   `Cr`   |
|    `F2`     | Gérer un profil utilisateur                                                   |   `El`   |
|    `F3`     | Sécuriser les accès                                                           |   `Ma`   |
|    `F4`     | Implementer assistance 24h (vocale, chat-bot, appel a un preposé)             |   `El`   |
|    `F5`     | Integrer fonction de réseaux sociaux                                          |   `No`   |
|    `F6`     | Implementer la reconnaissance photo                                           |   `In`   |
|    `F7`     | Evaluateur de capacités motrices                                              |   `El`   |
|    `F8`     | Gestion des quizs (ajout/suppression/modification des quizs) et des résultats |   `Ma`   |

## Récits Utilisateurs

Les récits utilisateurs font référence aux [personas définis ici](./personas.md). Dans une _vraie_ spécification, il faudrait aussi intégrer une définition de terminaison (_definition of done_, DoD) pour chacun des récits.

La valeur attribuée a chaque recit decrit la pertinence de celui ci par rapport a son persona. le domaine de definition de la pertinance est : ]0, 1].

0 : est une quantitée impossible, car on part du principe qu'un persona a la capacite de decrire un minimum ce qu'il veut.

1 : est la quantitée maximale qu'une valeur puisse avoir

| Id.  | ETQ          | JV                                                              | AD                                                      | Fonc. | Valeur |
| :--: | :----------- | :-------------------------------------------------------------- | :------------------------------------------------------ | :---: | :----: |
| `1`  | Fred         | accéder simplement aux quizs collectifs                         | choisir lequel je vais lancer                           | `F1`  |  0.9   |
| `2`  | Fred         | obtenir l'assistance d'un•e aidant•e                            | changer mes centres d'interêts                          | `F2`  |  0.8   |
| `3`  | Fred         | avoir accès aux quizs correspondant à mes centres d'interêts    | jouer avec des thèmes qui me plaisent                   | `F1`  |  0.9   |
| `4`  | Fred         | avoir accès à mes quizs personels                               | exercer ma mémoire                                      | `F1`  |  0.9   |
| `5`  | Camille      | utiliser un code d'accès                                        | sécuriser l'accès à mon profil                          | `F3`  |  0.8   |
| `6`  | Camille      | voir mes résultats aux quizs                                    | savoir où je dois m'améliorer                           | `F8`  |  0.9   |
| `7`  | Camille      | lister tous mes quizs                                           | choisir lequel je vais lancer                           | `F1`  |  0.9   |
| `8`  | Camille      | modifier mes centres d'interêts                                 | obtenir des recommandations                             | `F2`  |  0.8   |
| `9`  | Camille      | modifier la taile du texte a tout moment                        | continuer a jouer meme quand ma vue fatigue             | `F2`  |  0.2   |
| `10` | Dominique    | afficher les quizs disponibles                                  | selectionner mon quiz selon mon humeur                  | `F1`  |  0.9   |
| `11` | Dominique    | repondre a mon quiz vocalement                                  | de jouer la nuit ou quand ma vue baisse                 | `F4`  |  0.1   |
| `12` | Dominique    | connaitre le score des anciens quizs                            | savoir les tendences de ses performances                | `F8`  |  0.1   |
| `13` | Dominique    | veut que mon entourage soit au courant de mes performances      | recevoir un suivi proactif                              | `F2`  |  0.9   |
| `14` | Marie-France | avoir controle sur la generation de quiz                        | selectionner la thematique souhaitee des quiz           | `F2`  |  0.1   |
| `15` | Marie-France | assistance/aide en tout temps                                   | faire des quiz difficiles                               | `F4`  |  0.9   |
| `16` | Marie-France | acceder a l'application a l'aide d'empreinte                    | securiser l'acces a mon profil                          | `F3`  |  0.2   |
| `17` | Marie-France | recevoir des appréciations medicales quotidiennes               | suivre l'etat globale de ma sante mentale               | `F2`  |  0.9   |
| `18` | Jean         | personnaliser mes quizs                                         | excercer des points particuliers                        | `F1`  |  0.9   |
| `19` | Jean         | partager mes scores                                             | mes amis de residence puissent les voir                 | `F5`  |  0.1   |
| `20` | Jean         | rejouer des quizs ou j'ai echoué                                | ameliorer mes performances                              | `F1`  |  0.9   |
| `21` | Jean         | calculer mes taux de tremblements                               | suivre l'evolution de ma condition                      | `F7`  |  0.9   |
| `22` | Jean         | écouter l'énoncé d'un quiz                                      | pouvoir jouer meme quand ma vue fatigue                 | `F4`  |  0.1   |
| `23` | Jean         | assistance en tout temps pendant les quizs                      | pouvoir jouer en cas de perte de memoire momentanées    | `F4`  |  0.9   |
| `24` | Celia        | que l'administration des quizs soit protegé par un mot de passe | de garder une coherence dans les quizs                  | `F3`  |  0.9   |
| `25` | Celia        | suivre l'evolution des capacites motrices de mon groupe         | de focaliser mon travail de maniere plus efficace       | `F8`  |  0.9   |
| `26` | Celia        | compiler des donnees sur l'evolutions de sante des residents    | utiliser dans des projets de recherches                 | `F2`  |  0.1   |
| `28` | Cedric       | voir quotidiennement le taux de bonne reponse de mon groupe     | porter soin particulier aux residents qui en ont besoin | `F8`  |  0.9   |
| `29` | Cedric       | aider des residents dans les quizs                              | permettre a chacun de s'exercer                         | `F4`  |  0.9   |
| `30` | Gregory      | ajouter des quizs                                               | organiser des tournois avec thematiques                 | `F8`  |  0.9   |
| `31` | Gregory      | suivre les resultats de quizs                                   | ajuster le contenu des tournois et activites            | `F8`  |  0.9   |
| `32` | Jerome       | alimenter des souvenir et contenu de quizs pour ma mere         | permettre a ma mere de faire des quizs personnels       | `F8`  |  0.9   |

## Itérations

### Démonstration (Produit ni minimal, ni viable)

**Intention** : L'intention de cette itération est de démontrer ce qu'il ne faut pas faire, c.à.d. produire un logiciel n'apportant pas la valeur attendue à ses utilisateurs. Avec le produit ainsi défini, on est capable de se connecter, de gérer un profil, de voir des résulats ... mais on ne peut pas jouer à un quizz, alors que c'est la fonctionalités première du produit.

**Contenu de l'itération** :

- `F1` (_Jouer à un quizz_) : récits 1, 4, 6, 7 et 9
- `F2` (_Gérer un profil_) : récits 2, 3, 8 et 10
- `F3` (_Sécuriser les accès_) : récit 5

**Justification** : Dans cette itération, on met le focus sur la gestion des profils utilisateurs, et l'interface de connexion pour que chaque personna puisse accéder à sa liste de quizz disponibles.

### Produit Minimal Viable

**Intention** : L'intention de cette itération est d'établir un produit minimal viable. Dans ce contexte le produit démontre la capacité de jouer à un quiz. Cette fonctionalité représente la valeur première et ultime à l'audience-cible de l'application et permet a son audience de jouer a autant de quizs possibles. Aussi une autre fonctionalité est celle de la gestion des quizs. C'est a dire qu'un aide soignant ou autres professionels responsable auront la possibilite d'ajouter, supprimer ou modifier des quizs existant.
Pour les membre de la famille, ils peuvent apporter de nouvelles information pour enrichir les quizs personnels.
**Contenu de l'itération** :

- `F1` (_Jouer à un quizz_) : récits 1,3,4,7,9,12,17,22,24,29,35,36,41,42,48,52
- `F8` (_Gestion des quizs (ajout/suppression/modification des quizs) et des résultats_) : récits 6,12,25,28,30,31,32

**Justification** : Dans cette itération, on se focalise sur la fonction de jouer a un quiz. Aussi, la gestion des quizs et de leurs resultats. De ce fait, sa permet iaux personas residents de voir leurs resultats et aux personas aidant de concevoir des plans d'assistance et apporter un meilleur support aux residents sur un plan physique et mental.
