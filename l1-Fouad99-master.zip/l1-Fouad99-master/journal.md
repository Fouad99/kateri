# INF600G - Séquence 1 - Journal

- Auteur: Fouad M. serradj (`SERM21019100`)

Un cours de trois (3) crédits à l'UQAM correspond à neuf (9) heures de travail / semaine.

Le _budget temps_ à allouer au projet pour la première séquence est donc de vingt-sept (27) heures. La logistique du cours consomme au minimum 3h30 sur ce budget (3h de leçon introductive et deux rendez vous de 15 minutes), à vous d'organiser le reste.

Ne cherchez pas à _tomber juste_, mais effectuez plutôt une surveillance de votre temps de travail réel. Cela vous permettra de vous ajuster pour les autres séquences, et de mieux mesurer votre effort.

## Semaine 1 : Démarrage de la séquence

| Date  | Durée | Tâche                                           |
| :---: | :---: | :---------------------------------------------- |
| 05.05 |  3h   | Leçon introductive                              |
| 07.05 | 1h30  | Participation à la séance de questions/réponses |

## Semaine 2 : Suivi du travail

| Date  |  Durée  | Tâche                                                                |
| :---: | :-----: | :------------------------------------------------------------------- |
| 12.05 |   2h    | debut de mise en place des personas                                  |
| 13.05 |  2h30   | debut de mise en place de fonctionalites                             |
| 14.05 | 15 mins | Rendez-vous de suivi - Personas pas assez diversifie                 |
| 14.05 |  2h30   | Modification et ajout de nouveaux personas et changement de notation |

## Semaine 3 : Suivi du travail & Livraison

| Date  |  Durée  | Tâche                                          |
| :---: | :-----: | :--------------------------------------------- |
| 19.05 |   2h    | Debut de mise en place des recits utilisateurs |
| 20.05 |  2h30   | Mise en place de la premiere interaction       |
| 21.05 | 15 mins | Rendez-vous de suivi- Trop de personas         |
| 23.05 |   1h    | Modification des personas et changement MVP    |
| 24.05 |   3h    | Finalisation de la maquette et journal         |

## Retrospective

On utilise le cadre de reflexion _Starfish_ pour faire une rétrospective de la séquence passée.

- Ce que je dois continuer à faire : _Etre proactif, poser des questions_
- Ce que je dois faire plus : _chercher le maximum de feedback_
- Ce que je dois commencer à faire : _Organiser mon travaille de maniere quotidienne_
- Ce que je dois moins faire : _Travailler seul_
- Ce que je dois arrêter de faire : _procrastiner et ignorer certaines taches sous pretexte qu'elle sont simple a faires_
